set define off verify off feedback off
whenever sqlerror exit sql.sqlcode rollback
--------------------------------------------------------------------------------
--
-- ORACLE Application Express (APEX) export file
--
-- You should run the script connected to SQL*Plus as the Oracle user
-- APEX_050000 or as the owner (parsing schema) of the application.
--
-- NOTE: Calls to apex_application_install override the defaults below.
--
--------------------------------------------------------------------------------
begin
wwv_flow_api.import_begin (
 p_version_yyyy_mm_dd=>'2013.01.01'
,p_release=>'5.0.0.00.31'
,p_default_workspace_id=>3876307076513158
,p_default_application_id=>116
,p_default_owner=>'TS_ADMIN'
);
end;
/
prompt --application/ui_types
begin
null;
end;
/
prompt --application/shared_components/plugins/item_type/ca_essilordev_itsolutions_recaptcha277202
begin
wwv_flow_api.create_plugin(
 p_id=>wwv_flow_api.id(41757861586236903)
,p_plugin_type=>'ITEM TYPE'
,p_name=>'CA.ESSILORDEV.ITSOLUTIONS.RECAPTCHA277202'
,p_display_name=>'Google reCaptcha2 APEX5'
,p_supported_ui_types=>'DESKTOP:JQM_SMARTPHONE'
,p_plsql_code=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'--==========================================================',
'-- This function renders the Google reCaptcha version 2 item ',
'--==========================================================',
'function render_recaptcha (p_item                in apex_plugin.t_page_item,',
'                           p_plugin              in apex_plugin.t_plugin,',
'                           p_value               in varchar2,',
'                           p_is_readonly         in boolean,',
'                           p_is_printer_friendly in boolean) return apex_plugin.t_page_item_render_result is',
'',
'  l_name            varchar2(30);',
'  l_public_key      varchar2(4000) := p_plugin.attribute_01;',
'  l_theme           varchar2(10)   := p_item.attribute_01;',
'  l_type            varchar2(10)   := p_item.attribute_02;',
'  l_size            varchar2(10)   := p_item.attribute_03;',
'  l_tabindex        varchar2(10)   := p_item.attribute_04;',
'  l_callback        varchar2(50)   := p_item.attribute_05;',
'  l_expiredCallback varchar2(50)   := p_item.attribute_06;',
'  l_lang            varchar2(255)  := nvl(p_item.attribute_07, ''en'');',
'  l_error           varchar2(255)  := p_item.attribute_08;',
'  ',
'  l_result     apex_plugin.t_page_item_render_result;',
'',
'begin',
'  -- Check plug-in configuration',
'  if l_public_key is null then',
'    raise_application_error(-20999, ''No Public Key has been set for the reCaptcha plug-in! You can get one at https://www.google.com/recaptcha/admin/create'');',
'  end if;',
'',
'  -- If we are in printer friendly mode we are NOT generating the reCaptcha.',
'  if p_is_printer_friendly then',
'    return l_result;',
'  end if;',
'',
'  -- Captcha page item will be a single value field',
'  l_name := apex_plugin.get_input_name_for_page_item (p_is_multi_value => false );',
'',
'  -- Container which will hold the reCaptcha widget',
'  htp.p(''<div id="'' || p_item.name || ''"></div>'');',
'  ',
'  -- onloadCallback function that will called once the api.js library is loaded',
'  htp.p(''<script type="text/javascript">',
'            var onloadCallback = function() {',
'              //alert("gRecaptcha is ready");',
'              grecaptcha.render("'' || p_item.name || ''", {'' ||',
'                                apex_javascript.add_attribute(''sitekey'', l_public_key, true, true) ||',
'                                apex_javascript.add_attribute(''theme'', l_theme, true, true) ||',
'                                apex_javascript.add_attribute(''type'', l_type, true, true) ||',
'                                apex_javascript.add_attribute(''size'', l_size, true, true) ||',
'                                apex_javascript.add_attribute(''tabindex'', l_tabindex, true, true) ||',
'                                case when l_callback is not null then ''"callback" : '' || l_callback || '','' end ||',
'                                case when l_expiredCallback is not null then ''"expired-callback" : '' || l_expiredCallback end ||',
'                              ''});',
'              apex.jQuery(document).bind("apexbeforepagesubmit", function(){apex.jQuery("#g-recaptcha-response").attr("name", "'' || l_name || ''");});',
'              apex.jQuery("#g-recaptcha-response").focus();'' || ''',
'            }',
'         </script>'');',
'',
'  -- Add api.js library with onloadCallback, explicit and language options',
'  htp.p(''<script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit&hl='' || l_lang || ''" async defer></script>'');',
'',
'  -- Set field as not navigable',
'  l_result.is_navigable := false;',
'',
'  -- if in debug mode, debugging information will displayed in the debug window',
'  apex_plugin_util.debug_page_item(p_plugin, p_item, p_value, p_is_readonly, p_is_printer_friendly);',
'',
'  return l_result;',
'end render_recaptcha;',
'',
'',
'--=====================================================================================',
'-- This fucntion validates the reCaptcha response value against the Google web service.',
'--=====================================================================================',
'function validate_recaptcha (p_item   in apex_plugin.t_page_item,',
'                             p_plugin in apex_plugin.t_plugin,',
'                             p_value  in varchar2) return apex_plugin.t_page_item_validation_result is',
'',
'  l_private_key     varchar2(4000) := p_plugin.attribute_02;',
'  l_wallet_path     varchar2(4000) := p_plugin.attribute_03;',
'  l_wallet_pwd      varchar2(4000) := p_plugin.attribute_04;',
'  l_error_msg       varchar2(4000) := nvl(p_item.attribute_08, ''Please Check the reCaptcha box before proceeding.'');',
'',
'  l_parm_name_list  apex_application_global.vc_arr2;',
'  l_parm_value_list apex_application_global.vc_arr2;',
'  l_rest_result     varchar2(32767);',
'',
'  l_result          apex_plugin.t_page_item_validation_result;',
'begin',
'  -- Check if plug-in private key is set',
'  if l_private_key is null then',
'    raise_application_error(-20999, ''No Private Key has been set for the reCaptcha plug-in! Get one at https://www.google.com/recaptcha/admin/create'');',
'  end if;',
'',
'  -- Has the user checked the reCaptcha Box and responded to the challenge?',
'  if p_value is null then',
'    l_result.message := l_error_msg;',
'    return l_result;',
'  end if;',
'',
'  -- Build the parameters list for the post action.',
'  -- See https://code.google.com/apis/recaptcha/docs/verify.html for more details',
'',
'  l_parm_name_list (1) := ''secret'';',
'  l_parm_value_list(1) := l_private_key;',
'  l_parm_name_list (2) := ''response'';',
'  l_parm_value_list(2) := p_value; --l_value_list(2);',
'  l_parm_name_list (3) := ''remoteip'';',
'  l_parm_value_list(3) := owa_util.get_cgi_env(''REMOTE_ADDR'');',
'',
'  -- Set web service header rest request',
'  apex_web_service.g_request_headers(1).name  := ''Content-Type'';',
'  apex_web_service.g_request_headers(1).value := ''application/x-www-form-urlencoded'';',
'',
'  -- Call the reCaptcha REST service to verify the response against the private key',
'  l_rest_result := wwv_flow_utilities.clob_to_varchar2(',
'                       apex_web_service.make_rest_request(',
'                           p_url         => ''https://www.google.com/recaptcha/api/siteverify'',',
'                           p_http_method => ''POST'',',
'                           p_parm_name   => l_parm_name_list,',
'                           p_parm_value  => l_parm_value_list,',
'                           p_wallet_path => l_wallet_path,',
'                           p_wallet_pwd  => l_wallet_pwd));',
'',
'  -- Delete the request header',
'  apex_web_service.g_request_headers.delete;',
'',
'  -- Check the HTTPS status call',
'  if apex_web_service.g_status_code = ''200'' then -- sucessful call',
'    -- Check the returned json for successfull validation',
'    apex_json.parse(l_rest_result);',
'    if apex_json.get_varchar2(p_path => ''success'') = ''false'' then',
'      l_result.message := l_rest_result;',
'      /* possible errors are :',
'         Error code	            Description',
'         ---------------------- ------------------------------------------------',
'         missing-input-secret	The secret parameter is missing.',
'         invalid-input-secret	The secret parameter is invalid or malformed.',
'         missing-input-response	The response parameter is missing.',
'         invalid-input-response	The response parameter is invalid or malformed.',
'      */',
'    else -- success = ''true''',
'      l_result.message := null;',
'      --l_result.message := l_rest_result;',
'    end if;',
'  else -- unsucessful call',
'    l_result.message := ''reCaptcha HTTPS request status : '' || apex_web_service.g_status_code;',
'  end if;',
'',
'  -- if in debug mode, debugging information will displayed in the debug window',
'  apex_plugin_util.debug_page_item(p_plugin, p_item, p_value, true, false);',
'  ',
'  return l_result;',
'end validate_recaptcha;',
''))
,p_render_function=>'render_recaptcha'
,p_validation_function=>'validate_recaptcha'
,p_standard_attributes=>'VISIBLE'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_help_text=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'Network ACL Setup',
'------------------------------------------------------------------------------------------------------',
'On Oracle Database 11g or higher, you will need an ACL to allow access to external network services.',
'Here is an 11g example of creating an ACL to allow the APEX_050000 user to access "google.com".',
'',
'CONN / AS SYSDBA',
'BEGIN',
'  DBMS_NETWORK_ACL_ADMIN.create_acl (',
'    acl          => ''googleReCaptcha.xml'', ',
'    description  => ''An ACL for the google reCaptcha website'',',
'    principal    => ''APEX_050000'',',
'    is_grant     => TRUE, ',
'    privilege    => ''connect'',',
'    start_date   => SYSTIMESTAMP,',
'    end_date     => NULL);',
'',
'  DBMS_NETWORK_ACL_ADMIN.assign_acl (',
'    acl         => ''googleReCaptcha.xml'',',
'    host        => ''google.com'', ',
'    lower_port  => 80,',
'    upper_port  => 80); ',
'',
'  COMMIT;',
'END;',
'/',
'------------------------------------------------------------------------------------------------------',
'On Oracle Database 12c use the following approach:',
'',
'CONN / AS SYSDBA',
'BEGIN',
'  DBMS_NETWORK_ACL_ADMIN.append_host_ace (',
'    host       => ''google.com'', ',
'    lower_port => 80,',
'    upper_port => 80,',
'    ace        => xs$ace_type(privilege_list => xs$name_list(''http''),',
'                              principal_name => ''APEX_050000'',',
'                              principal_type => xs_acl.ptype_db)); ',
'END;',
'/',
'------------------------------------------------------------------------------------------------------',
'HTTPS (SSL) Web Services',
'',
'Google reCapcha verification needs an HTTPS (SSL) connection, For you will need to an Oracle wallet to hold the trusted certificates. You can see how that is done here <https://oracle-base.com/articles/misc/utl_http-and-ssl>.',
'',
'The MAKE_REQUEST and MAKE_REST_REQUEST routines accept P_WALLET_PATH and P_WALLET_PWD parameters, allowing you to specify the wallet location and password.',
'',
'p_wallet_path => ''file:/home/oracle/wallet'',',
'p_wallet_pwd  => ''MyPassword1''',
'------------------------------------------------------------------------------------------------------',
'This plugin allows you to enter wallet information as parameters. If the wallet information are not provided, then the plugin rely on the wallet information defined in the APEX Admin Instance Setup (Home>Manage Instance>Instance Settings)',
'------------------------------------------------------------------------------------------------------',
'If your network requires a proxy server to access the Internet, then you need to it setup either on Oracle APEX instance level (Application>Edit Application Properties) or on application level (Home>Manage Instance>Security).',
'-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'))
,p_version_identifier=>'1.0'
,p_plugin_comment=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'Author:',
'Mohamed Zebib',
'23-DEC-2015',
''))
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41758098640236916)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Public Key'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI'
,p_display_length=>50
,p_is_translatable=>true
,p_examples=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'The provided default Public Key a google Public Key for testing purpose:',
'6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI'))
,p_help_text=>'Public Key required to render the reCaptcha. Get a key for your domain at <a href="https://www.google.com/recaptcha/admin/create" target="_blank">https://www.google.com/recaptcha/admin/create</a>.'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41758486109236926)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Private Key'
,p_attribute_type=>'TEXT'
,p_is_required=>true
,p_default_value=>'6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'
,p_display_length=>50
,p_is_translatable=>true
,p_examples=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'The provided default Private Key a google Private Key for testing purpose:',
'6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'))
,p_help_text=>'Private Key required to verify the reCaptcha value. Get a key for your domain at <a href="https://www.google.com/recaptcha/admin/create" target="_blank">https://www.google.com/recaptcha/admin/create</a>.'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41758816682236926)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'Wallet Path'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_display_length=>50
,p_is_translatable=>true
,p_examples=>'file:D:\oracle\admin\<your_database_sid>\<your_wallet_directory_name>'
,p_help_text=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'Enter the path of your Oracle Wallet. for example:',
'The entered Wallet Path will overwrite any setup done in the APEX Administration Wallet setup described below:',
'-----------------------------------------------------------------------------------------------------',
'For a more secure setup:',
'-----------------------------------------------------------------------------------------------------',
'Connect to Apex as internal admin user,',
'Goto Home>Manage Instance>Instance Settings',
'set Wallet Path : file:D:\ORACLE\ADMIN\<your_database_sid>\WALLET',
'set Wallet Password: <Wallet Password>'))
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41759249133236927)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'APPLICATION'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'Wallet Password'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_display_length=>50
,p_is_translatable=>true
,p_help_text=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'Enter the password of your Oracle Wallet.',
'The entered Wallet Password will overwrite any setup done in the APEX Administration Wallet setup described below:',
'-----------------------------------------------------------------------------------------------------',
'For a more secure setup:',
'-----------------------------------------------------------------------------------------------------',
'Connect to Apex as internal admin user,',
'Goto Home>Manage Instance>Instance Settings',
'set Wallet Path : file:D:\ORACLE\ADMIN\<your_database_sid>\WALLET',
'set Wallet Password: <Wallet Password>'))
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41759664938236927)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>1
,p_display_sequence=>10
,p_prompt=>'Theme'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'light'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_examples=>'light'
,p_help_text=>'Optional. The color theme of the widget.'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41760065380236928)
,p_plugin_attribute_id=>wwv_flow_api.id(41759664938236927)
,p_display_sequence=>10
,p_display_value=>'Dark'
,p_return_value=>'dark'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41760555669236930)
,p_plugin_attribute_id=>wwv_flow_api.id(41759664938236927)
,p_display_sequence=>20
,p_display_value=>'Light'
,p_return_value=>'light'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41761045554236932)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>2
,p_display_sequence=>20
,p_prompt=>'Type'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'image'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_examples=>'Image'
,p_help_text=>'Optional. The type of CAPTCHA to serve.'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41761415819236933)
,p_plugin_attribute_id=>wwv_flow_api.id(41761045554236932)
,p_display_sequence=>10
,p_display_value=>'Audio'
,p_return_value=>'audio'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41761997564236934)
,p_plugin_attribute_id=>wwv_flow_api.id(41761045554236932)
,p_display_sequence=>20
,p_display_value=>'Image'
,p_return_value=>'image'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41762440349236934)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>3
,p_display_sequence=>30
,p_prompt=>'Size'
,p_attribute_type=>'SELECT LIST'
,p_is_required=>true
,p_default_value=>'normal'
,p_is_translatable=>false
,p_lov_type=>'STATIC'
,p_examples=>'Normal'
,p_help_text=>'Optional. The size of the widget.'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41762828245236935)
,p_plugin_attribute_id=>wwv_flow_api.id(41762440349236934)
,p_display_sequence=>10
,p_display_value=>'Compact'
,p_return_value=>'compact'
);
wwv_flow_api.create_plugin_attr_value(
 p_id=>wwv_flow_api.id(41763327317236935)
,p_plugin_attribute_id=>wwv_flow_api.id(41762440349236934)
,p_display_sequence=>20
,p_display_value=>'Normal'
,p_return_value=>'normal'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41763800310236936)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>4
,p_display_sequence=>40
,p_prompt=>'Tabindex'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_default_value=>'0'
,p_is_translatable=>true
,p_help_text=>'Optional. The tabindex of the widget and challenge. If other elements in your page use tabindex, it should be set to make user navigation easier.'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41764270557236942)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>5
,p_display_sequence=>50
,p_prompt=>'Callback'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_is_translatable=>true
,p_examples=>'var displayCaptchaResponse = function(response) {alert(response);};'
,p_help_text=>'Optional. The name of your callback function to be executed when the user submits a successful CAPTCHA response. The user''s response, g-recaptcha-response, will be the input for your callback function.'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41764638814236943)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>6
,p_display_sequence=>60
,p_prompt=>'ExpiredCallback'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_is_translatable=>true
,p_examples=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'var displayCaptchaExpiryMessage = function() {',
'                                    //alert(''Recaptcha Expired. Please refresh your screen and try again'');',
'                                    console.log(''Recaptcha Expired. Please refresh your screen and try again'');',
'                             };'))
,p_help_text=>'Optional. The name of your callback function to be executed when the recaptcha response expires and the user needs to solve a new CAPTCHA.'
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41799450500028615)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>7
,p_display_sequence=>70
,p_prompt=>'Language'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_default_value=>'en'
,p_is_translatable=>true
,p_examples=>'en'
,p_help_text=>wwv_flow_utilities.join(wwv_flow_t_varchar2(
'<h2>Language	Code</h2>',
'<p></p>',
'<p>Arabic	<b>ar</b></p>',
'<p>Afrikaans	<b>af</b></p>',
'<p>Amharic	<b>am</b></p>',
'<p>Armenian	<b>hy</b></p>',
'<p>Azerbaijani	<b>az</b></p>',
'<p>Basque	<b>eu</b></p>',
'<p>Bengali	<b>bn</b></p>',
'<p>Bulgarian	<b>bg</b></p>',
'<p>Catalan	<b>ca</b></p>',
'<p>Chinese (Hong Kong)	<b>zh-HK</b></p>',
'<p>Chinese (Simplified)	<b>zh-CN</b></p>',
'<p>Chinese (Traditional)	<b>zh-TW</b></p>',
'<p>Croatian	<b>hr</b></p>',
'<p>Czech	<b>cs</b></p>',
'<p>Danish	<b>da</b></p>',
'<p>Dutch	<b>nl</b></p>',
'<p>English (UK)	<b>en-GB</b></p>',
'<p>English (US)	<b>en</b></p>',
'<p>Estonian	<b>et</b></p>',
'<p>Filipino	<b>fil</b></p>',
'<p>Finnish	<b>fi</b></p>',
'<p>French	<b>fr</b></p>',
'<p>French (Canadian)	<b>fr-CA</b></p>',
'<p>Galician	<b>gl</b></p>',
'<p>Georgian	<b>ka</b></p>',
'<p>German	<b>de</b></p>',
'<p>German (Austria)	<b>de-AT</b></p>',
'<p>German (Switzerland)	<b>de-CH</b></p>',
'<p>Greek	<b>el</b></p>',
'<p>Gujarati	<b>gu</b></p>',
'<p>Hebrew	<b>iw</b></p>',
'<p>Hindi	<b>hi</b></p>',
'<p>Hungarain	<b>hu</b></p>',
'<p>Icelandic	<b>is</b></p>',
'<p>Indonesian	<b>id</b></p>',
'<p>Italian	<b>it</b></p>',
'<p>Japanese	<b>ja</b></p>',
'<p>Kannada	<b>kn</b></p>',
'<p>Korean	<b>ko</b></p>',
'<p>Laothian	<b>lo</b></p>',
'<p>Latvian	<b>lv</b></p>',
'Lithuanian	<b>lt',
'<p>Malay	<b>ms</b></p>',
'<p>Malayalam	<b>ml</b></p>',
'<p><p>Marathi	<b>mr</b></p></b></p>',
'<p>Mongolian	<b>mn</b></p>',
'<p>Norwegian	<b>no</b></p>',
'<p>Persian	<b>fa</b></p>',
'<p>Polish	<b>pl</b></p>',
'<p>Portuguese	<b>pt</b></p>',
'<p>Portuguese (Brazil)	<b>pt-BR</b></p>',
'<p>Portuguese (Portugal)	<b>pt-PT</b></p>',
'<p>Romanian	<b>ro</b></p>',
'<p>Russian	<b>ru</b></p>',
'<p>Serbian	<b>sr</b></p>',
'<p>Sinhalese	<b>si</b></p>',
'<p>Slovak	<b>sk</b></p>',
'<p>Slovenian	<b>sl</b></p>',
'<p>Spanish	<b>es</b></p>',
'<p>Spanish (Latin America)	<b>es-419</b></p>',
'<p>Swahili	<b>sw</b></p>',
'<p>Swedish	<b>sv</b></p>',
'<p>Tamil	<b>ta</b></p>',
'<p>Telugu	<b>te</b></p>',
'<p>Thai	<b>th</b></p>',
'<p>Turkish	<b>tr</b></p>',
'<p>Ukrainian	<b>uk</b></p>',
'<p>Urdu	<b>ur</b></p>',
'<p>Vietnamese	<b>vi</b></p>',
'<p>Zulu	<b>zu</b></p>'))
);
wwv_flow_api.create_plugin_attribute(
 p_id=>wwv_flow_api.id(41800291028031420)
,p_plugin_id=>wwv_flow_api.id(41757861586236903)
,p_attribute_scope=>'COMPONENT'
,p_attribute_sequence=>8
,p_display_sequence=>80
,p_prompt=>'Error Message if captcha box not checked'
,p_attribute_type=>'TEXT'
,p_is_required=>false
,p_default_value=>'Please Check the reCaptcha box before proceeding.'
,p_is_translatable=>true
,p_examples=>'Please Check the reCaptcha box before proceeding.'
,p_help_text=>'This message will appear whenever the user submits the page without checking the reCaptcha checkbox.'
);
end;
/
begin
wwv_flow_api.import_end(p_auto_install_sup_obj => nvl(wwv_flow_application_install.get_auto_install_sup_obj, false), p_is_component_import => true);
commit;
end;
/
set verify on feedback on define on
prompt  ...done
